from chalice import Chalice, NotFoundError, BadRequestError
import boto3
import uuid
from datetime import datetime
import os  # For environment variables (optional for table name)

app = Chalice(app_name="chalice-todo-backend")
app.debug = True  # Optional: for more detailed error messages during development

# Option 1: Get table name from environment variable (recommended for flexibility)
# DYNAMODB_TABLE_NAME = os.environ.get('DYNAMODB_TABLE_NAME', 'ChaliceTodoListTable')
# Option 2: Hardcode table name (simpler for this example)
DYNAMODB_TABLE_NAME = (
    "ChaliceTodoListTable"  # <<< MAKE SURE THIS MATCHES YOUR TABLE NAME
)

dynamodb = None
if os.environ.get("AWS_LAMBDA_FUNCTION_NAME"):  # Check if running in AWS Lambda
    dynamodb = boto3.resource("dynamodb")
else:  # For local development, ensure your AWS CLI is configured
    # You might need to specify region if not in default AWS CLI config
    # session = boto3.Session(region_name='your-aws-region')
    # dynamodb = session.resource('dynamodb')
    dynamodb = boto3.resource("dynamodb")  # Assumes default session is fine

table = dynamodb.Table(DYNAMODB_TABLE_NAME)


@app.route("/", methods=["GET"])
def index():
    return {"message": "Welcome to the Chalice To-Do List API!"}


@app.route("/tasks", methods=["POST"])
def add_task():
    task_data = app.current_request.json_body
    title = task_data.get("title")
    due_date_str = task_data.get("dueDate")  # Expected format: YYYY-MM-DD

    if not title or not due_date_str:
        raise BadRequestError("Task 'title' and 'dueDate' (YYYY-MM-DD) are required.")

    try:
        datetime.strptime(due_date_str, "%Y-%m-%d")
    except ValueError:
        raise BadRequestError("Invalid 'dueDate' format. Please use YYYY-MM-DD.")

    task_id = str(uuid.uuid4())
    timestamp = datetime.utcnow().isoformat()

    item = {
        "taskId": task_id,
        "title": title,
        "dueDate": due_date_str,
        "completed": False,
        "createdAt": timestamp,
        "updatedAt": timestamp,
    }

    try:
        table.put_item(Item=item)
        app.log.info(f"Task added: {task_id} - {title}")
        return {"message": "Task added successfully", "task": item}, 201
    except Exception as e:
        app.log.error(f"Error adding task: {e}")
        raise ChaliceViewError("Could not add task")


@app.route("/tasks", methods=["GET"])
def list_tasks():
    try:
        # For a real app, consider pagination for large datasets
        response = table.scan()
        # Sort by due date, then by creation date if due dates are the same
        tasks = sorted(
            response.get("Items", []), key=lambda x: (x["dueDate"], x["createdAt"])
        )
        return {"tasks": tasks}
    except Exception as e:
        app.log.error(f"Error listing tasks: {e}")
        raise ChaliceViewError("Could not list tasks")


@app.route("/tasks/{task_id}", methods=["GET"])
def get_task(task_id):
    try:
        response = table.get_item(Key={"taskId": task_id})
        if "Item" not in response:
            raise NotFoundError(f"Task with ID '{task_id}' not found.")
        return {"task": response["Item"]}
    except Exception as e:
        app.log.error(f"Error getting task {task_id}: {e}")
        if isinstance(e, NotFoundError):
            raise
        raise ChaliceViewError(f"Could not get task {task_id}")


@app.route("/tasks/{task_id}", methods=["PUT"])
def update_task(task_id):
    updates = app.current_request.json_body
    if not updates:
        raise BadRequestError(
            "No update data provided. Provide 'title', 'dueDate', or 'completed'."
        )

    # Check if task exists
    try:
        response = table.get_item(Key={"taskId": task_id})
        if "Item" not in response:
            raise NotFoundError(f"Task with ID '{task_id}' not found.")
    except Exception as e:
        app.log.error(f"Error finding task {task_id} for update: {e}")
        if isinstance(e, NotFoundError):
            raise
        raise ChaliceViewError(f"Could not find task {task_id} to update")

    update_expression_parts = []
    expression_attribute_values = {}
    expression_attribute_names = {}  # For reserved keywords if any

    if "title" in updates:
        update_expression_parts.append("#t = :title")
        expression_attribute_names["#t"] = (
            "title"  # 'title' is not reserved, but good practice
        )
        expression_attribute_values[":title"] = updates["title"]
    if "dueDate" in updates:
        try:
            datetime.strptime(updates["dueDate"], "%Y-%m-%d")
            update_expression_parts.append("dueDate = :dueDate")
            expression_attribute_values[":dueDate"] = updates["dueDate"]
        except ValueError:
            raise BadRequestError("Invalid 'dueDate' format. Please use YYYY-MM-DD.")
    if "completed" in updates and isinstance(updates["completed"], bool):
        update_expression_parts.append("completed = :completed")
        expression_attribute_values[":completed"] = updates["completed"]

    if not update_expression_parts:
        raise BadRequestError("No valid fields provided for update.")

    update_expression_parts.append("updatedAt = :updatedAt")  # Always update timestamp
    expression_attribute_values[":updatedAt"] = datetime.utcnow().isoformat()

    update_expression = "SET " + ", ".join(update_expression_parts)

    try:
        updated_item = table.update_item(
            Key={"taskId": task_id},
            UpdateExpression=update_expression,
            ExpressionAttributeValues=expression_attribute_values,
            ExpressionAttributeNames=(
                expression_attribute_names if expression_attribute_names else None
            ),
            ReturnValues="ALL_NEW",
        )
        app.log.info(f"Task updated: {task_id}")
        return {
            "message": "Task updated successfully",
            "task": updated_item["Attributes"],
        }
    except Exception as e:
        app.log.error(f"Error updating task {task_id}: {e}")
        raise ChaliceViewError(f"Could not update task {task_id}")


@app.route("/tasks/{task_id}", methods=["DELETE"])
def delete_task(task_id):
    try:
        # Ensure task exists before attempting delete for a clearer error
        response = table.get_item(Key={"taskId": task_id})
        if "Item" not in response:
            raise NotFoundError(f"Task with ID '{task_id}' not found.")

        table.delete_item(Key={"taskId": task_id})
        app.log.info(f"Task deleted: {task_id}")
        return {"message": f"Task '{task_id}' deleted successfully."}
    except Exception as e:
        app.log.error(f"Error deleting task {task_id}: {e}")
        if isinstance(e, NotFoundError):
            raise
        raise ChaliceViewError(f"Could not delete task {task_id}")
